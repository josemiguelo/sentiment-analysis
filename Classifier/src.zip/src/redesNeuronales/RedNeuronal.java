/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package redesNeuronales;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.functions.MultilayerPerceptron;
import weka.classifiers.misc.SerializedClassifier;
import weka.core.Debug;
import weka.core.Instances;
import weka.core.Utils;

/**
 *
 * @author Jose
 */
public class RedNeuronal {

    public void training(String paramNN) throws FileNotFoundException, IOException, Exception {
        //enrenamiento de la red neuronal con parámetros 
        FileReader trainReader = new FileReader("src\\archivos\\sickTrain.arff");
        //Instancias
        Instances trainInstance = new Instances(trainReader);
        trainInstance.setClassIndex(trainInstance.numAttributes() - 1);

        //Construir la red
        MultilayerPerceptron mlp = new MultilayerPerceptron();
        mlp.setOptions(Utils.splitOptions(paramNN)); //fijar parámetros de multilayerPerceptron
        mlp.buildClassifier(trainInstance);//construir clasificador

        //Guardar el perceptrón multicapa - generar el archivo
        Debug.saveToFile("TrainMLP.train", mlp);

        //Evaluar el entrenamiento
        SerializedClassifier sc = new SerializedClassifier();
        sc.setModelFile(new File("TrainMLP.train"));
        Evaluation evaluateTrain = new Evaluation(trainInstance);
        evaluateTrain.evaluateModel(mlp, trainInstance);//evaluación del modelo
        System.err.println(evaluateTrain.toSummaryString("******Resultados*********", false));
        System.err.println(evaluateTrain.toMatrixString("******Matriz de confusión****"));

        trainReader.close();
    }

    public void testing() throws FileNotFoundException, IOException, Exception {
        FileReader testReader = new FileReader("src\\archivos\\sickTest.arff");
        Instances testInstance = new Instances(testReader);
        testInstance.setClassIndex(testInstance.numAttributes() - 1);

        weka.classifiers.evaluation.Evaluation evaluateTest = new weka.classifiers.evaluation.Evaluation(testInstance);

        SerializedClassifier sc = new SerializedClassifier();
        sc.setModelFile(new File("TrainMLP.train"));

        //Cargar clasificardor desde el .train
        Classifier mlp = sc.getCurrentModel();

        evaluateTest.evaluateModel(mlp, testInstance);//devuelve un arreglo de dobles

        System.err.println(evaluateTest.toSummaryString("******Resultados*********", false));
        System.err.println(evaluateTest.toMatrixString("******Matriz de confusión****"));
    }
    
    public void validate() throws FileNotFoundException, IOException, Exception {
        FileReader testReader = new FileReader("src\\archivos\\sickValidate.arff");
        Instances testInstance = new Instances(testReader);
        testInstance.setClassIndex(testInstance.numAttributes() - 1);

        weka.classifiers.evaluation.Evaluation evaluateTest = new weka.classifiers.evaluation.Evaluation(testInstance);

        SerializedClassifier sc = new SerializedClassifier();
        sc.setModelFile(new File("TrainMLP.train"));

        //Cargar clasificardor desde el .train
        Classifier mlp = sc.getCurrentModel();

        evaluateTest.evaluateModel(mlp, testInstance);//devuelve un arreglo de dobles

        System.err.println(evaluateTest.toSummaryString("******Resultados*********", false));
        System.err.println(evaluateTest.toMatrixString("******Matriz de confusión****"));
    }
}
